"""Test evaluation of regex parser."""
import unittest

from automaton import FiniteAutomaton
from re_parser import REParser


class TestREParser(unittest.TestCase):
    """Tests for regex parser."""

    def _create_evaluator(self, regex):
        automaton = REParser().create_automaton(regex)
        return automaton

    def _check_accept(self, evaluator, string, should_accept = True):
        with self.subTest(string=string):
            accepted = evaluator.accepts(string)
            self.assertEqual(accepted, should_accept)

    def test_fixed(self):
        """Test fixed regex."""
        evaluator = self._create_evaluator("H.e.l.l.o")

        evaluator.draw(filename="test_fixed", view=False)

        self._check_accept(evaluator, "Hello", should_accept=True)
        self._check_accept(evaluator, "Helloo", should_accept=False)
        self._check_accept(evaluator, "Hell", should_accept=False)
        self._check_accept(evaluator, "llH", should_accept=False)
        self._check_accept(evaluator, "", should_accept=False)

    def test_star(self):
        """Test Kleene star."""
        evaluator = self._create_evaluator("a*.b*")

        evaluator.draw(filename="test_star", view=False)

        self._check_accept(evaluator, "", should_accept=True)
        self._check_accept(evaluator, "a", should_accept=True)
        self._check_accept(evaluator, "b", should_accept=True)
        self._check_accept(evaluator, "aa", should_accept=True)
        self._check_accept(evaluator, "bb", should_accept=True)
        self._check_accept(evaluator, "ab", should_accept=True)
        self._check_accept(evaluator, "ba", should_accept=False)
        self._check_accept(evaluator, "aab", should_accept=True)
        self._check_accept(evaluator, "abb", should_accept=True)
        self._check_accept(evaluator, "aba", should_accept=False)
        self._check_accept(evaluator, "bab", should_accept=False)

    def test_or(self):
        """Test Kleene star."""
        evaluator = self._create_evaluator("(a+b)*")

        evaluator.draw(filename="test_or", view=False)

        self._check_accept(evaluator, "", should_accept=True)
        self._check_accept(evaluator, "a", should_accept=True)
        self._check_accept(evaluator, "b", should_accept=True)
        self._check_accept(evaluator, "aa", should_accept=True)
        self._check_accept(evaluator, "bb", should_accept=True)
        self._check_accept(evaluator, "ab", should_accept=True)
        self._check_accept(evaluator, "ba", should_accept=True)
        self._check_accept(evaluator, "aab", should_accept=True)
        self._check_accept(evaluator, "abb", should_accept=True)
        self._check_accept(evaluator, "aba", should_accept=True)
        self._check_accept(evaluator, "bab", should_accept=True)

    def test_number(self):
        """Test number expression."""
        num = "(0+1+2+3+4+5+6+7+8+9)"
        evaluator = self._create_evaluator(
            f"({num}.{num}*.,.{num}*)+{num}*",
        )

        evaluator.draw(filename="test_number", view=False)

        self._check_accept(evaluator, ",", should_accept=False)
        self._check_accept(evaluator, "1,7", should_accept=True)
        self._check_accept(evaluator, "25,73", should_accept=True)
        self._check_accept(evaluator, "5027", should_accept=True)
        self._check_accept(evaluator, ",13", should_accept=False)
        self._check_accept(evaluator, "13,", should_accept=True)
        self._check_accept(evaluator, "3,7,12", should_accept=False)


    # Dos Tests adicionales  para el Ejercicio 2
    def test_fixed_adicional(self):
        """Test fixed regex."""
        evaluator = self._create_evaluator("W.o.r.l.d")

        evaluator.draw(filename="test_fixed_adicional", view=False)

        self._check_accept(evaluator, "World", should_accept=True)
        self._check_accept(evaluator, "Woorld", should_accept=False)
        self._check_accept(evaluator, "Wrld", should_accept=False)
        self._check_accept(evaluator, "Wor", should_accept=False)
        self._check_accept(evaluator, "rld", should_accept=False)
        self._check_accept(evaluator, "", should_accept=False)

    def test_phone_number(self):
        """Test for phone number expression """
        num = "(0+1+2+3+4+5+6+7+8+9)"

        # +34 624 528220 <- Ignoramos el +
        evaluator = self._create_evaluator(
            f"{num}.{num}. .{num}.{num}.{num}. .{num}.{num}.{num}.{num}.{num}.{num}",
        )

        evaluator.draw(filename="test_phone_number", view=False)

        self._check_accept(evaluator, "34 624 528220",  should_accept=True)
        self._check_accept(evaluator, "",               should_accept=False)
        self._check_accept(evaluator, "34624528220",    should_accept=False)
        self._check_accept(evaluator, "34 624 5282201", should_accept=False)
        self._check_accept(evaluator, "3 624 528220",   should_accept=False)
        self._check_accept(evaluator, "34 62 528220",   should_accept=False)
        self._check_accept(evaluator, "34-624-528220",  should_accept=False)



if __name__ == "__main__":
    unittest.main()
